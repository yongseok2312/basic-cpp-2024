#include <iostream>
#include "�߰�.h"

int main() {
	human h("a", 1, 1, 2);
	h.printhuman();


	return 0;
}